
import os

INPUT_PATH = os.getenv("INPUT_PATH", "s3://my-bucket/input-data/")
OUTPUT_PATH = os.getenv("OUTPUT_PATH", "s3://my-bucket/output-data/")
