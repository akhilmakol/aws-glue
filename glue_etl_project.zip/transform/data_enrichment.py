
from pyspark.sql.functions import current_timestamp

def enrich_data(df):
    return df.withColumn("processed_time", current_timestamp())
