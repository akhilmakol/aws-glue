
def clean_data(df):
    return df.dropna().dropDuplicates()
