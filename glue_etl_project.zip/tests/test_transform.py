
def test_clean_data(spark_session):
    from transform.data_cleaning import clean_data
    df = spark_session.createDataFrame([
        (1, "Alice"),
        (2, None),
        (1, "Alice")
    ], ["id", "name"])
    cleaned = clean_data(df)
    assert cleaned.count() == 1

def test_enrich_data(spark_session):
    from transform.data_enrichment import enrich_data
    df = spark_session.createDataFrame([(1, "Alice")], ["id", "name"])
    enriched = enrich_data(df)
    assert "processed_time" in enriched.columns
